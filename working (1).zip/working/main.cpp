#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <chrono>
#include <mutex>
#include <atomic>
#include <curl/curl.h>
#include <iomanip>
#include <sstream>
#ifdef _WIN32
#include <windows.h>
#endif
#include "gpu_accelerated.h"
#include "offline_checker.h"

std::vector<std::string> wordlist;
std::atomic<unsigned long long> total_checked(0);
std::atomic<unsigned long long> wallets_with_balance(0);
std::mutex output_mutex;
auto start_time = std::chrono::high_resolution_clock::now();

// Offline checking
OfflineChecker offline_checker;
bool use_offline_mode = false;

void update_console_title() {
    auto current_time = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::seconds>(current_time - start_time);
    double wallets_per_second = duration.count() > 0 ? total_checked.load() / (double)duration.count() : 0;
    
    std::ostringstream title;
    title << "[WalletGen | GPU] - Searching for BTC wallets / [Checked mnemonics: " 
          << total_checked << " | Found balance: " << std::fixed << std::setprecision(7) 
          << wallets_with_balance.load() << " | Speed: " << (int)wallets_per_second << "/s]";
    
#ifdef _WIN32
    SetConsoleTitleA(title.str().c_str());
#else
    std::cout << "\033]0;" << title.str() << "\007" << std::flush;
#endif
}

void display_wallet_check(const std::string& mnemonic, const std::string& btc_address, const std::string& eth_address, bool btc_balance, bool eth_balance) {
    std::lock_guard<std::mutex> lock(output_mutex);
    
    std::cout << "mnemonic:     " << mnemonic << std::endl;
    std::cout << "btc address:  " << btc_address;
    if (btc_balance) std::cout << " *** BTC FOUND ***";
    std::cout << std::endl;
    
    std::cout << "eth address:  " << eth_address;
    if (eth_balance) std::cout << " *** ETH FOUND ***";
    std::cout << std::endl;
    
    if (btc_balance || eth_balance) {
        std::cout << "STATUS:       *** WALLET WITH BALANCE FOUND ***" << std::endl;
    } else {
        std::cout << "STATUS:       (empty)" << std::endl;
    }
    
    std::cout << "===================================================================" << std::endl;
}

void load_wordlist() {
    std::ifstream file("bip39-words.txt");
    std::string word;
    while (std::getline(file, word)) {
        if (!word.empty() && word.back() == '\r') {
            word.pop_back();
        }
        wordlist.push_back(word);
    }
    std::cout << "Loaded " << wordlist.size() << " words from BIP39 wordlist" << std::endl;
}

size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* response) {
    response->append((char*)contents, size * nmemb);
    return size * nmemb;
}

bool check_balance(const std::string& address) {
    CURL* curl;
    CURLcode res;
    std::string response;

    curl = curl_easy_init();
    if (!curl) return false;

    std::string url = "https://blockstream.info/api/address/" + address;

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L); // Increased timeout
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "WalletGenerator/1.0");

    res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        std::lock_guard<std::mutex> lock(output_mutex);
        std::cerr << "CURL Error for " << address << ": " << curl_easy_strerror(res) << std::endl;
        return false;
    }

    if (response.empty()) {
        std::lock_guard<std::mutex> lock(output_mutex);
        std::cerr << "Empty response for address: " << address << std::endl;
        return false;
    }

    // Check if funded_txo_sum exists and is greater than 0
    size_t funded_pos = response.find("\"funded_txo_sum\":");
    if (funded_pos == std::string::npos) {
        // Also check for spent_txo_sum as an alternative indicator
        size_t spent_pos = response.find("\"spent_txo_sum\":");
        if (spent_pos != std::string::npos) {
            size_t value_start = response.find(":", spent_pos) + 1;
            size_t value_end = response.find_first_of(",}", value_start);
            if (value_start != std::string::npos && value_end != std::string::npos) {
                std::string value = response.substr(value_start, value_end - value_start);
                value.erase(0, value.find_first_not_of(" \t\n\r"));
                value.erase(value.find_last_not_of(" \t\n\r") + 1);
                if (value != "0" && !value.empty()) {
                    // Log potential balance found for debugging
                    std::lock_guard<std::mutex> lock(output_mutex);
                    std::cout << "DEBUG: Address " << address << " has spent_txo_sum: " << value << std::endl;
                    return true;
                }
            }
        }
        return false;
    }
    
    // Extract the value after "funded_txo_sum":
    size_t value_start = response.find(":", funded_pos) + 1;
    size_t value_end = response.find_first_of(",}", value_start);
    
    if (value_start != std::string::npos && value_end != std::string::npos) {
        std::string value = response.substr(value_start, value_end - value_start);
        // Remove whitespace
        value.erase(0, value.find_first_not_of(" \t\n\r"));
        value.erase(value.find_last_not_of(" \t\n\r") + 1);
        
        // Check if value is not "0"
        if (value != "0" && !value.empty()) {
            // Log balance found for verification
            std::lock_guard<std::mutex> lock(output_mutex);
            std::cout << "DEBUG: Address " << address << " has funded_txo_sum: " << value << std::endl;
            return true;
        }
    }
    
    return false;
}

void save_wallet(const std::string& mnemonic, const std::string& btc_address, const std::string& eth_address, const std::string& private_key, bool btc_found, bool eth_found) {
    std::lock_guard<std::mutex> lock(output_mutex);
    
    // Verify file can be opened
    std::ofstream file("found_wallets.txt", std::ios::app);
    if (!file.is_open()) {
        std::cerr << "ERROR: Could not open found_wallets.txt for writing!" << std::endl;
        return;
    }
    
    // Get current timestamp in readable format
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    auto unix_timestamp = std::chrono::duration_cast<std::chrono::seconds>(now.time_since_epoch()).count();
    
    file << "=== WALLET FOUND ===" << std::endl;
    file << "Mnemonic: " << mnemonic << std::endl;
    file << "BTC Address: " << btc_address;
    if (btc_found) file << " (BALANCE FOUND)";
    file << std::endl;
    file << "ETH Address: " << eth_address;
    if (eth_found) file << " (BALANCE FOUND)";
    file << std::endl;
    file << "Private Key: " << private_key << std::endl;
    file << "Unix Timestamp: " << unix_timestamp << std::endl;
    file << "Date: " << std::ctime(&time_t); // This adds a newline
    file << "Total Found: " << (wallets_with_balance.load() + 1) << std::endl;
    file << "===================" << std::endl;
    file << std::endl; // Extra line for readability
    file.close();
    
    // Verify file was written successfully
    if (file.good()) {
        wallets_with_balance++;
        std::cout << "\n*** WALLET WITH BALANCE FOUND ***" << std::endl;
        std::cout << "Mnemonic: " << mnemonic << std::endl;
        if (btc_found) std::cout << "BTC Address: " << btc_address << " (BALANCE FOUND)" << std::endl;
        if (eth_found) std::cout << "ETH Address: " << eth_address << " (BALANCE FOUND)" << std::endl;
        std::cout << "Private Key: " << private_key << std::endl;
        std::cout << "Successfully saved to found_wallets.txt" << std::endl;
        std::cout << "Total wallets with balance found: " << wallets_with_balance.load() << std::endl;
        std::cout << "********************************" << std::endl;
    } else {
        std::cerr << "ERROR: Failed to write wallet to file!" << std::endl;
    }
}

int main(int argc, char* argv[]) {
    std::cout << "CUDA-Accelerated Multi-Chain Wallet Generator (RTX 3060)" << std::endl;
    std::cout << "=========================================================" << std::endl;
    std::cout << "GPU-ONLY MODE - Bitcoin & Ethereum Support" << std::endl;
    std::cout << "=========================================================" << std::endl;

    // Check for offline mode
    if (argc > 1 && std::string(argv[1]) == "--offline") {
        std::string address_file = "addresses.txt";
        if (argc > 2) {
            address_file = argv[2];
        }
        
        std::cout << "OFFLINE MODE: Using address file " << address_file << std::endl;
        if (offline_checker.load_addresses_from_file(address_file)) {
            use_offline_mode = true;
            std::cout << "Offline checking enabled with " 
                      << offline_checker.get_btc_count() << " BTC and " 
                      << offline_checker.get_evm_count() << " EVM addresses" << std::endl;
        } else {
            std::cerr << "Failed to load addresses from file. Exiting." << std::endl;
            return 1;
        }
    } else {
        std::cout << "ONLINE MODE: Using Blockstream API for balance checking" << std::endl;
        std::cout << "Use --offline [address_file] for offline checking" << std::endl;
    }

    // Load wordlist
    load_wordlist();
    if (wordlist.size() != 2048) {
        std::cerr << "Error: BIP39 wordlist must contain exactly 2048 words" << std::endl;
        return 1;
    }

    // Initialize CUDA
    if (!init_gpu_system(wordlist)) {
        std::cerr << "Failed to initialize CUDA system" << std::endl;
        return 1;
    }

    std::cout << "Starting continuous GPU wallet generation..." << std::endl;
    std::cout << "Checking both Bitcoin and Ethereum addresses" << std::endl;
    std::cout << "Press Ctrl+C to stop" << std::endl;

    const int BATCH_SIZE = 100; // Smaller batches for real-time display
    start_time = std::chrono::high_resolution_clock::now();

    while (true) {
        // Generate batch on GPU
        WalletBatch batch = generate_wallet_batch_gpu(BATCH_SIZE);

        // Check each wallet individually and display in real-time
        for (size_t i = 0; i < batch.addresses.size(); i++) {
            if (!batch.addresses[i].empty() && batch.addresses[i] != "INVALID") {
                total_checked++;
                
                // Generate Ethereum address from the same private key
                std::string eth_address = private_key_to_eth_address(batch.private_keys[i]);
                
                bool btc_balance = false;
                bool eth_balance = false;
                
                if (use_offline_mode) {
                    // Offline checking
                    btc_balance = offline_checker.check_btc_address(batch.addresses[i]);
                    eth_balance = offline_checker.check_evm_address(eth_address);
                } else {
                    // Online checking
                    btc_balance = check_balance(batch.addresses[i]);
                    // Note: ETH balance checking would need additional API integration
                }
                
                // Display every wallet check
                display_wallet_check(batch.mnemonics[i], batch.addresses[i], eth_address, btc_balance, eth_balance);
                
                if (btc_balance || eth_balance) {
                    save_wallet(batch.mnemonics[i], batch.addresses[i], eth_address, batch.private_keys[i], btc_balance, eth_balance);
                }
                
                // Update console title every 10 wallets
                if (total_checked % 10 == 0) {
                    update_console_title();
                }
            }
        }
    }

    cleanup_gpu_system();
    return 0;
}